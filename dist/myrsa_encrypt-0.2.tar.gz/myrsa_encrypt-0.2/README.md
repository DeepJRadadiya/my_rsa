# My RSA Library

This is a simple implementation of RSA encryption and decryption in Python without using built-in RSA libraries.

## Installation

```bash
pip install myrsa_encrypt
